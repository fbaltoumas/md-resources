MARTINI CHOLESTEROL (CHL1) topology and parameters in CHARMM-like format for use with NAMD v. 2.10 and above

Based on the cholesterol mapping and topology presented in:
Marrink et al, The MARTINI force field: Coarse Grained Model for Biomolecular Simulations, J. Phys. Chem. B 2007, 111, 7812-7824
(See Fig. 1 and table 2 in the paper)

Written by Fotis Baltoumas
(fbaltoumas@biol.uoa.gr)

This package consists of the three following files:
->martini-cholesterol.top: The topology file for MARTINI cholesterol.
->martini-cholesterol.par: The parameters file for MARTINI cholesterol.
->martini-cholesterol-c36.cgc: A mapping scheme table for converting all-atom cholesterol to its Coarse-Grained form, compatible with VMD's CG Tools plugin.


Notes:
1. Mapping and molecule and atom names are based on the CHARMM36 version of cholesterol (CHL1). Please prepare your structure using the CHARMM36 topology prior to coarse-graining.

2. The parameters include all needed terms for simulation of cholesterol, i.e. bonds, angles, dihedrals/impropers and non-bonded interactions.

3. No other MARTINI force field elements are included in the package. In order to perform simulations, you need to download the rest of the MARTINI lipid and protein force field in CHARMM format from the NAMD website.  You can find NAMD compatible topology and parameters in the following link:
http://www.ks.uiuc.edu/Training/Tutorials/martini/files.tar.gz

4. This cholesterol model is compatible with the MARTINI version available from the link above.  It is NOT compatible with the CHARMM version of the BMW-MARTINI model from Yethiraj's group, since that version does not implement the cosine based angle potential. However, it is possible to import it, simply by changing the angle term in the parameters file accordingly.

5. According to the original authors, the GROMACS cholesterol topology/parameters are stable with an integration timestep of up to 30 fs. This NAMD version has been proven to be most stable when using a 20 fs integration timestep. Simulations with a 30 fs timestep value may also be performed, provided the system has received proper equilibration and the temperature is controlled adequately.

6. Concerning the cholesterol particles: These are the same as the normal SP1, SC1, SC3 and C1 particles. However, we have used the same solution that was done for the NAMD version of the MARTINI protein field and defined "new" particles, so that there were no duplication issues. As a result, just like the HIS SP1 particle was renamed as SP1h, these particles are defined anew, specifically for cholesterol. 

7. A brief note concerning bonds that in GROMACS would be constrained: Since one cannot easily constrain bonds in NAMD, instead we set their force constants (k) to a large value. The same trick was used when importing the MARTINI extension to proteins in NAMD. Ideally k should be as large as possible without causing NAMD to crash. In practice, a value of 40 kcal/mol/A^2 has proven to be most effective i.e. no simulation crashes occured, no deformation of the molecule was observed and output energy values were in good agreement with the ones produced by simulating the same system using GROMACS.  However, feel free to change these values if you need to. Bond constraints are identified by the "constraint" comment accompanying them in the parameters file.

8. Finally, and most importantly, this cholesterol model is fully functional with the standard version of NAMD, i.e. no editing of the original source code and recompiling is required.


